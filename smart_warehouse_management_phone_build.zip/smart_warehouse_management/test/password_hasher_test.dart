import 'package:flutter_test/flutter_test.dart';
import 'package:smart_warehouse_management/utils/password_hasher.dart';
void main(){test('password hashes verify and reject invalid input',(){final h=PasswordHasher.hash('StrongPassword!');expect(h.contains('StrongPassword!'),isFalse);expect(PasswordHasher.verify('StrongPassword!',h),isTrue);expect(PasswordHasher.verify('wrong',h),isFalse);});}

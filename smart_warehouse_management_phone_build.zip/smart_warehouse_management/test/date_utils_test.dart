import 'package:flutter_test/flutter_test.dart';
import 'package:smart_warehouse_management/utils/date_utils.dart';
void main(){test('month range is start inclusive and next month exclusive',(){final r=DateRangeHelper.monthRange(2026,8);expect(r.start,DateTime(2026,8,1));expect(r.end,DateTime(2026,9,1));});}

package com.bashar.smartwarehouse
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()

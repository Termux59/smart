# إدارة ذكية للمخازن — Smart Warehouse Management

تطبيق Flutter محلي Offline لإدارة المخزون باستخدام Provider + SQLite + Local Notifications بدون Firebase أو Cloud.

## التشغيل

1. استخدم Flutter 3.47.x / Dart 3.13 أو أحدث متوافق.
2. من جذر المشروع: `flutter pub get`
3. ثم: `flutter analyze`
4. للتشغيل: `flutter run`
5. لإنشاء APK: `flutter build apk --release`

> الحساب الإداري الأولي: `admin` / `Admin@123`. غيّر كلمة المرور من الإعدادات بعد أول دخول.

## ملاحظات Android

- minSdk 24 / compileSdk 36 / targetSdk 36.
- التطبيق يطلب Camera وNotifications وExact Alarm فقط حسب الوظائف المطلوبة.
- ScheduledNotificationBootReceiver مضاف لاستعادة الإشعارات المجدولة بعد إعادة تشغيل الجهاز.
- بعض الشركات المصنّعة قد تقيّد المنبهات في الخلفية؛ قد يلزم السماح للتطبيق بالعمل في الخلفية من إعدادات الهاتف.

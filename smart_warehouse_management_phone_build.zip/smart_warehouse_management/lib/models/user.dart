enum UserRole { admin, employee }

class AppUser {
  final int? id;
  final String username;
  final String passwordHash;
  final UserRole role;
  final bool active;
  final DateTime createdAt;

  const AppUser({this.id, required this.username, required this.passwordHash, required this.role, this.active = true, required this.createdAt});

  bool get isAdmin => role == UserRole.admin;

  factory AppUser.fromMap(Map<String, Object?> map) => AppUser(
    id: map['id'] as int?,
    username: map['username'] as String,
    passwordHash: map['password_hash'] as String,
    role: (map['role'] as String) == 'admin' ? UserRole.admin : UserRole.employee,
    active: (map['active'] as int? ?? 1) == 1,
    createdAt: DateTime.parse(map['created_at'] as String),
  );

  Map<String, Object?> toMap() => {
    if (id != null) 'id': id,
    'username': username,
    'password_hash': passwordHash,
    'role': role.name,
    'active': active ? 1 : 0,
    'created_at': createdAt.toIso8601String(),
  };
}

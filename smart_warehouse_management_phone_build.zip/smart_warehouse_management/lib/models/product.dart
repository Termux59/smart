import '../utils/date_utils.dart';

enum ProductExpiryState { valid, month, week, threeDays, expired }

class Product {
  final int? id;
  final String name;
  final String? imagePath;
  final String barcode;
  final int? categoryId;
  final int? supplierId;
  final String manufacturer;
  final int quantity;
  final int minimumStock;
  final double purchasePrice;
  final double sellingPrice;
  final DateTime? productionDate;
  final DateTime? expiryDate;
  final String storageLocation;
  final String shelfNumber;
  final String notes;
  final DateTime createdAt;
  final DateTime updatedAt;

  const Product({this.id, required this.name, this.imagePath, required this.barcode, this.categoryId, this.supplierId, this.manufacturer = '', required this.quantity, required this.minimumStock, required this.purchasePrice, required this.sellingPrice, this.productionDate, this.expiryDate, this.storageLocation = '', this.shelfNumber = '', this.notes = '', required this.createdAt, required this.updatedAt});

  bool get lowStock => quantity <= minimumStock;
  int? get daysRemaining => expiryDate == null ? null : DateRangeHelper.daysUntil(expiryDate!);
  ProductExpiryState get expiryState {
    final days = daysRemaining;
    if (days == null) return ProductExpiryState.valid;
    if (days < 0) return ProductExpiryState.expired;
    if (days <= 3) return ProductExpiryState.threeDays;
    if (days <= 7) return ProductExpiryState.week;
    if (days <= 30) return ProductExpiryState.month;
    return ProductExpiryState.valid;
  }

  Product copyWith({int? id, String? name, String? imagePath, String? barcode, int? categoryId, int? supplierId, String? manufacturer, int? quantity, int? minimumStock, double? purchasePrice, double? sellingPrice, DateTime? productionDate, DateTime? expiryDate, String? storageLocation, String? shelfNumber, String? notes, DateTime? createdAt, DateTime? updatedAt}) => Product(
    id: id ?? this.id, name: name ?? this.name, imagePath: imagePath ?? this.imagePath, barcode: barcode ?? this.barcode, categoryId: categoryId ?? this.categoryId, supplierId: supplierId ?? this.supplierId, manufacturer: manufacturer ?? this.manufacturer, quantity: quantity ?? this.quantity, minimumStock: minimumStock ?? this.minimumStock, purchasePrice: purchasePrice ?? this.purchasePrice, sellingPrice: sellingPrice ?? this.sellingPrice, productionDate: productionDate ?? this.productionDate, expiryDate: expiryDate ?? this.expiryDate, storageLocation: storageLocation ?? this.storageLocation, shelfNumber: shelfNumber ?? this.shelfNumber, notes: notes ?? this.notes, createdAt: createdAt ?? this.createdAt, updatedAt: updatedAt ?? this.updatedAt,
  );

  factory Product.fromMap(Map<String, Object?> m) => Product(
    id: m['id'] as int?, name: m['name'] as String, imagePath: m['image_path'] as String?, barcode: m['barcode'] as String? ?? '', categoryId: m['category_id'] as int?, supplierId: m['supplier_id'] as int?, manufacturer: m['manufacturer'] as String? ?? '', quantity: m['quantity'] as int? ?? 0, minimumStock: m['minimum_stock'] as int? ?? 0, purchasePrice: (m['purchase_price'] as num? ?? 0).toDouble(), sellingPrice: (m['selling_price'] as num? ?? 0).toDouble(), productionDate: m['production_date'] == null ? null : DateTime.parse(m['production_date'] as String), expiryDate: m['expiry_date'] == null ? null : DateTime.parse(m['expiry_date'] as String), storageLocation: m['storage_location'] as String? ?? '', shelfNumber: m['shelf_number'] as String? ?? '', notes: m['notes'] as String? ?? '', createdAt: DateTime.parse(m['created_at'] as String), updatedAt: DateTime.parse(m['updated_at'] as String),
  );

  Map<String, Object?> toMap() => {
    if (id != null) 'id': id, 'name': name, 'image_path': imagePath, 'barcode': barcode, 'category_id': categoryId, 'supplier_id': supplierId, 'manufacturer': manufacturer, 'quantity': quantity, 'minimum_stock': minimumStock, 'purchase_price': purchasePrice, 'selling_price': sellingPrice, 'production_date': productionDate?.toIso8601String(), 'expiry_date': expiryDate?.toIso8601String(), 'storage_location': storageLocation, 'shelf_number': shelfNumber, 'notes': notes, 'created_at': createdAt.toIso8601String(), 'updated_at': updatedAt.toIso8601String(),
  };
}

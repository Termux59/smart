import 'product.dart';
class TransactionLine {
  final Product product; final int quantity; final double unitPrice;
  const TransactionLine({required this.product, required this.quantity, required this.unitPrice});
  double get total => quantity * unitPrice;
}

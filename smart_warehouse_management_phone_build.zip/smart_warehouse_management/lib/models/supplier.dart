class Supplier {
  final int? id; final String name; final String phone; final String address; final String email; final String notes;
  const Supplier({this.id, required this.name, this.phone='', this.address='', this.email='', this.notes=''});
  factory Supplier.fromMap(Map<String,Object?> m)=>Supplier(id:m['id'] as int?,name:m['name'] as String,phone:m['phone'] as String? ?? '',address:m['address'] as String? ?? '',email:m['email'] as String? ?? '',notes:m['notes'] as String? ?? '');
  Map<String,Object?> toMap()=>{if(id!=null)'id':id,'name':name,'phone':phone,'address':address,'email':email,'notes':notes};
}

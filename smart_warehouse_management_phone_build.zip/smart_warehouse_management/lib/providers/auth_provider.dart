import 'package:flutter/foundation.dart';
import '../models/user.dart'; import '../services/authentication_service.dart';
class AuthProvider extends ChangeNotifier { final _service=AuthenticationService(); AppUser? user; bool loading=false; String? error; bool get loggedIn=>user!=null; bool get isAdmin=>user?.isAdmin??false;
  Future<void> restore() async { loading=true; notifyListeners(); user=await _service.restoreSession(); loading=false; notifyListeners(); }
  Future<bool> login(String u,String p,bool remember) async { loading=true; error=null; notifyListeners(); try{user=await _service.login(u,p,remember:remember); if(user==null)error='اسم المستخدم أو كلمة المرور غير صحيحة';}catch(e){error='تعذر تسجيل الدخول: $e';} loading=false; notifyListeners(); return user!=null; }
  Future<void> logout() async { await _service.logout(); user=null; notifyListeners(); }
}

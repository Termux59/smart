import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import '../database/database_service.dart';
import '../models/product.dart';
import '../utils/constants.dart';

class NotificationService {
  NotificationService._();
  static final instance = NotificationService._();
  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    tzdata.initializeTimeZones();
    try {
      final zone = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(zone.name));
    } catch (_) {}
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    await _plugin.initialize(settings: const InitializationSettings(android: android));
    final androidPlugin = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.requestNotificationsPermission();
    await androidPlugin?.requestExactAlarmsPermission();
    await _createChannels();
  }

  Future<void> _createChannels() async {
    final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await android?.createNotificationChannel(const AndroidNotificationChannel(
      AppConstants.expiryChannelId, 'تنبيهات انتهاء الصلاحية',
      description: 'تنبيهات المنتجات القريبة من الانتهاء والمنتهية', importance: Importance.high,
    ));
    await android?.createNotificationChannel(const AndroidNotificationChannel(
      AppConstants.stockChannelId, 'تنبيهات المخزون',
      description: 'تنبيهات انخفاض المخزون والحد الأدنى', importance: Importance.high,
    ));
  }

  int _expiryId(int productId, int days) => productId * 100 + (days + 40);
  int _stockId(int productId) => 100000000 + productId;

  Future<void> scheduleProductExpiry(Product product) async {
    if (product.id == null || product.expiryDate == null) return;
    await cancelProductExpiry(product.id!);
    final enabled = await DatabaseService.instance.getSetting('notifications_enabled') == '1';
    if (!enabled) return;
    for (final days in const [30,14,7,3,1,0]) {
      if (await DatabaseService.instance.getSetting('notify_$days') != '1') continue;
      final targetDate = product.expiryDate!.subtract(Duration(days: days));
      final scheduled = tz.TZDateTime(tz.local, targetDate.year, targetDate.month, targetDate.day, 9);
      if (!scheduled.isAfter(tz.TZDateTime.now(tz.local))) continue;
      final title = days == 0 ? '⚠️ انتهاء صلاحية اليوم' : '⚠️ تنبيه انتهاء صلاحية';
      final body = days == 0 ? 'المنتج "${product.name}" تنتهي صلاحيته اليوم. يرجى مراجعة المخزون.' : 'المنتج "${product.name}" سينتهي بعد $days يوم. يرجى مراجعة المخزون.';
      final id = _expiryId(product.id!, days);
      await _plugin.zonedSchedule(
        id: id, title: title, body: body, scheduledDate: scheduled,
        notificationDetails: const NotificationDetails(android: AndroidNotificationDetails(
          AppConstants.expiryChannelId, 'تنبيهات انتهاء الصلاحية', channelDescription: 'تنبيهات صلاحية المنتجات', importance: Importance.high, priority: Priority.high,
        )),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        payload: 'product:${product.id}',
      );
      await DatabaseService.instance.addNotificationRecord({'product_id':product.id,'type':days==0?'expired':'expiry','title':title,'body':body,'scheduled_at':scheduled.toIso8601String(),'created_at':DateTime.now().toIso8601String(),'is_read':0,'system_notification_id':id});
    }
  }

  Future<void> cancelProductExpiry(int productId) async {
    for (final days in const [30,14,7,3,1,0]) { await _plugin.cancel(id: _expiryId(productId, days)); }
    await DatabaseService.instance.deleteProductNotificationRecords(productId);
  }

  Future<void> checkLowStock(Product product) async {
    if (product.id == null || !product.lowStock) return;
    if (await DatabaseService.instance.getSetting('notifications_enabled') != '1') return;
    final title='⚠️ المخزون منخفض'; final body='المنتج "${product.name}" كميته ${product.quantity} والحد الأدنى ${product.minimumStock}. يحتاج إلى إعادة الطلب.';
    final id=_stockId(product.id!);
    await _plugin.show(id: id,title:title,body:body,notificationDetails: const NotificationDetails(android:AndroidNotificationDetails(AppConstants.stockChannelId,'تنبيهات المخزون',channelDescription:'تنبيهات انخفاض المخزون',importance:Importance.high,priority:Priority.high)),payload:'product:${product.id}');
    await DatabaseService.instance.addNotificationRecord({'product_id':product.id,'type':'low_stock','title':title,'body':body,'created_at':DateTime.now().toIso8601String(),'is_read':0,'system_notification_id':id});
  }

  Future<void> cancelAll() => _plugin.cancelAll();

  Future<void> reconcileAllProducts() async {
    if (await DatabaseService.instance.getSetting('notifications_enabled') != '1') return;
    final products=await DatabaseService.instance.getProducts();
    for(final p in products) { if(p.expiryDate!=null) await scheduleProductExpiry(p); if(p.lowStock) await checkLowStock(p); }
  }
}

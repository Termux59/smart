import 'package:shared_preferences/shared_preferences.dart';
import '../database/database_service.dart';
import '../models/user.dart';
import '../utils/constants.dart';

class AuthenticationService {
  Future<AppUser?> login(String username,String password,{required bool remember}) async {
    final user=await DatabaseService.instance.authenticate(username,password); if(user==null)return null;
    final prefs=await SharedPreferences.getInstance(); await prefs.setBool(AppConstants.rememberMeKey,remember); if(remember) await prefs.setInt(AppConstants.sessionUserIdKey,user.id!); else await prefs.remove(AppConstants.sessionUserIdKey); return user;
  }
  Future<AppUser?> restoreSession() async { final prefs=await SharedPreferences.getInstance(); if(!(prefs.getBool(AppConstants.rememberMeKey)??false))return null; final id=prefs.getInt(AppConstants.sessionUserIdKey); if(id==null)return null; final rows=await DatabaseService.instance.db.query('users',where:'id=? AND active=1',whereArgs:[id],limit:1); return rows.isEmpty?null:AppUser.fromMap(rows.first); }
  Future<void> logout() async { final prefs=await SharedPreferences.getInstance(); await prefs.remove(AppConstants.sessionUserIdKey); await prefs.setBool(AppConstants.rememberMeKey,false); }
}

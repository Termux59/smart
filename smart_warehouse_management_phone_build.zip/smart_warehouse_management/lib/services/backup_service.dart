import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../database/database_service.dart';

class BackupService {
  Future<Directory> _backupDir() async { final root=await getApplicationDocumentsDirectory(); final dir=Directory(p.join(root.path,'backups')); if(!await dir.exists()) await dir.create(recursive:true); return dir; }
  Future<File> createBackup() async {
    await DatabaseService.instance.checkpoint();
    final source=File(await DatabaseService.instance.databasePath());
    final dir=await _backupDir();
    final stamp=DateTime.now().toIso8601String().replaceAll(':','-').split('.').first;
    return source.copy(p.join(dir.path,'smart_warehouse_$stamp.db'));
  }
  Future<List<File>> backups() async { final dir=await _backupDir(); final files=(await dir.list().where((e)=>e is File && e.path.endsWith('.db')).cast<File>().toList())..sort((a,b)=>b.path.compareTo(a.path)); return files; }
  Future<void> shareBackup(File file) => SharePlus.instance.share(ShareParams(files:[XFile(file.path)],text:'نسخة احتياطية - إدارة ذكية للمخازن'));
  Future<void> restore(File backup) async {
    if(!await backup.exists()) throw StateError('ملف النسخة الاحتياطية غير موجود');
    final target=await DatabaseService.instance.databasePath();
    await DatabaseService.instance.close();
    await backup.copy(target);
    await DatabaseService.instance.reopen();
  }
}

import 'dart:io';
import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import '../database/database_service.dart';

class ReportService {
  String reportName(String type) => {'inventory':'تقرير المخزون','expired':'المنتجات المنتهية','expiring':'القريبة من الانتهاء','low':'المخزون المنخفض','sales':'المبيعات','purchases':'المشتريات','profits':'الأرباح','movements':'حركة المخزون'}[type] ?? type;
  Future<File> createExcel(String type) async {
    final rows=await DatabaseService.instance.reportRows(type); final book=Excel.createExcel(); final sheet=book['Report'];
    if(rows.isNotEmpty){ final keys=rows.first.keys.toList(); sheet.appendRow(keys.map(TextCellValue.new).toList()); for(final r in rows){ sheet.appendRow(keys.map((k)=>TextCellValue('${r[k]??''}')).toList()); }}
    final bytes=book.encode(); if(bytes==null) throw StateError('تعذر إنشاء Excel'); final dir=await getApplicationDocumentsDirectory(); final f=File('${dir.path}/report_${type}_${DateTime.now().millisecondsSinceEpoch}.xlsx'); await f.writeAsBytes(bytes,flush:true); return f;
  }
  Future<File> createPdf(String type) async {
    final rows=await DatabaseService.instance.reportRows(type); final doc=pw.Document();
    final keys=rows.isEmpty?<String>[]:rows.first.keys.toList();
    doc.addPage(pw.MultiPage(pageFormat:PdfPageFormat.a4,build:(c)=>[
      pw.Text('Smart Warehouse Management',style:pw.TextStyle(fontSize:18,fontWeight:pw.FontWeight.bold)),pw.SizedBox(height:8),
      pw.Text(reportName(type),style:const pw.TextStyle(fontSize:14)),pw.SizedBox(height:12),
      if(rows.isEmpty) pw.Text('No data') else pw.TableHelper.fromTextArray(headers:keys,data:rows.map((r)=>keys.map((k)=>_safePdfText(r[k])).toList()).toList(),headerStyle:pw.TextStyle(fontWeight:pw.FontWeight.bold),cellStyle:const pw.TextStyle(fontSize:8)),
    ]));
    final dir=await getApplicationDocumentsDirectory(); final f=File('${dir.path}/report_${type}_${DateTime.now().millisecondsSinceEpoch}.pdf'); await f.writeAsBytes(await doc.save(),flush:true); return f;
  }
  String _safePdfText(Object? value) { final s='${value??''}'; return s.runes.every((r)=>r<256)?s:'[Unicode data]'; }
  Future<void> share(File file) => SharePlus.instance.share(ShareParams(files:[XFile(file.path)],text:'تقرير من إدارة ذكية للمخازن'));
}

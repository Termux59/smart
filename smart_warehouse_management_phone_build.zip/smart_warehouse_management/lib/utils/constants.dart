class AppConstants {
  static const appNameAr = 'إدارة ذكية للمخازن';
  static const appNameEn = 'Smart Warehouse Management';
  static const author = 'إعداد المهندس بشار عادل مزاحم';
  static const databaseName = 'smart_warehouse.db';
  static const databaseVersion = 1;
  static const sessionUserIdKey = 'session_user_id';
  static const rememberMeKey = 'remember_me';
  static const themeModeKey = 'theme_mode';
  static const expiryChannelId = 'expiry_alerts';
  static const stockChannelId = 'stock_alerts';
}

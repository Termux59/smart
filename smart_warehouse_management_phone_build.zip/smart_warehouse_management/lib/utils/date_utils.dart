class DateRangeHelper {
  static ({DateTime start, DateTime end}) monthRange(int year, int month) {
    final start = DateTime(year, month, 1);
    final end = month == 12 ? DateTime(year + 1, 1, 1) : DateTime(year, month + 1, 1);
    return (start: start, end: end);
  }

  static String sqlDate(DateTime value) => value.toIso8601String();

  static int daysUntil(DateTime date) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final target = DateTime(date.year, date.month, date.day);
    return target.difference(today).inDays;
  }
}

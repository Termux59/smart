import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';

class PasswordHasher {
  static const _iterations = 100000;
  static const _keyLength = 32;

  static String hash(String password, {String? saltBase64}) {
    final salt = saltBase64 == null ? _randomBytes(16) : base64Decode(saltBase64);
    final key = _pbkdf2(utf8.encode(password), salt, _iterations, _keyLength);
    return 'pbkdf2_sha256\$$_iterations\$${base64Encode(salt)}\$${base64Encode(key)}';
  }

  static bool verify(String password, String stored) {
    final parts = stored.split(r'$');
    if (parts.length != 4 || parts[0] != 'pbkdf2_sha256') return false;
    final iterations = int.tryParse(parts[1]);
    if (iterations == null) return false;
    final salt = base64Decode(parts[2]);
    final expected = base64Decode(parts[3]);
    final actual = _pbkdf2(utf8.encode(password), salt, iterations, expected.length);
    if (actual.length != expected.length) return false;
    var diff = 0;
    for (var i = 0; i < actual.length; i++) diff |= actual[i] ^ expected[i];
    return diff == 0;
  }

  static Uint8List _randomBytes(int length) {
    final random = Random.secure();
    return Uint8List.fromList(List<int>.generate(length, (_) => random.nextInt(256)));
  }

  static Uint8List _pbkdf2(List<int> password, List<int> salt, int iterations, int length) {
    final hmac = Hmac(sha256, password);
    final result = <int>[];
    var block = 1;
    while (result.length < length) {
      final blockBytes = Uint8List(4)
        ..[0] = (block >> 24) & 0xff
        ..[1] = (block >> 16) & 0xff
        ..[2] = (block >> 8) & 0xff
        ..[3] = block & 0xff;
      var u = hmac.convert([...salt, ...blockBytes]).bytes;
      final t = List<int>.from(u);
      for (var i = 1; i < iterations; i++) {
        u = hmac.convert(u).bytes;
        for (var j = 0; j < t.length; j++) t[j] ^= u[j];
      }
      result.addAll(t);
      block++;
    }
    return Uint8List.fromList(result.take(length).toList());
  }
}

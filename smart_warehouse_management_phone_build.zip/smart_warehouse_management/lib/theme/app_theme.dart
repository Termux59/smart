import 'package:flutter/material.dart';
class AppTheme {
  static const navy=Color(0xFF0B1F3A); static const blue=Color(0xFF1976D2);
  static ThemeData light()=>ThemeData(useMaterial3:true,colorScheme:ColorScheme.fromSeed(seedColor:navy,brightness:Brightness.light),scaffoldBackgroundColor:const Color(0xFFF6F8FB),cardTheme:const CardThemeData(elevation:0,margin:EdgeInsets.zero),inputDecorationTheme:const InputDecorationTheme(border:OutlineInputBorder()));
  static ThemeData dark()=>ThemeData(useMaterial3:true,colorScheme:ColorScheme.fromSeed(seedColor:blue,brightness:Brightness.dark),cardTheme:const CardThemeData(elevation:0,margin:EdgeInsets.zero),inputDecorationTheme:const InputDecorationTheme(border:OutlineInputBorder()));
}

import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import '../models/category.dart';
import '../models/product.dart';
import '../models/supplier.dart';
import '../models/user.dart';
import '../models/line_item.dart';
import '../utils/constants.dart';
import '../utils/date_utils.dart';
import '../utils/password_hasher.dart';

class DatabaseService {
  DatabaseService._();
  static final DatabaseService instance = DatabaseService._();
  Database? _db;
  Database get db => _db!;

  Future<void> init() async {
    final base = await getDatabasesPath();
    final path = p.join(base, AppConstants.databaseName);
    _db = await openDatabase(path, version: AppConstants.databaseVersion, onConfigure: (db) async {
      await db.execute('PRAGMA foreign_keys = ON');
    }, onCreate: _createSchema);
    await _seedDefaults();
  }

  Future<void> _createSchema(Database db, int version) async {
    await db.execute('''CREATE TABLE users(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('admin','employee')),
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    )''');
    await db.execute('''CREATE TABLE categories(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE
    )''');
    await db.execute('''CREATE TABLE suppliers(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT,
      address TEXT,
      email TEXT,
      notes TEXT
    )''');
    await db.execute('''CREATE TABLE products(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      image_path TEXT,
      barcode TEXT UNIQUE,
      category_id INTEGER,
      supplier_id INTEGER,
      manufacturer TEXT,
      quantity INTEGER NOT NULL DEFAULT 0 CHECK(quantity >= 0),
      minimum_stock INTEGER NOT NULL DEFAULT 0 CHECK(minimum_stock >= 0),
      purchase_price REAL NOT NULL DEFAULT 0 CHECK(purchase_price >= 0),
      selling_price REAL NOT NULL DEFAULT 0 CHECK(selling_price >= 0),
      production_date TEXT,
      expiry_date TEXT,
      storage_location TEXT,
      shelf_number TEXT,
      notes TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE SET NULL,
      FOREIGN KEY(supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL
    )''');
    await db.execute('''CREATE TABLE sales(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      total REAL NOT NULL,
      profit REAL NOT NULL,
      created_at TEXT NOT NULL,
      notes TEXT,
      FOREIGN KEY(user_id) REFERENCES users(id)
    )''');
    await db.execute('''CREATE TABLE sale_items(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sale_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      quantity INTEGER NOT NULL,
      purchase_price REAL NOT NULL,
      selling_price REAL NOT NULL,
      line_total REAL NOT NULL,
      line_profit REAL NOT NULL,
      FOREIGN KEY(sale_id) REFERENCES sales(id) ON DELETE CASCADE,
      FOREIGN KEY(product_id) REFERENCES products(id)
    )''');
    await db.execute('''CREATE TABLE purchases(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      supplier_id INTEGER,
      invoice_number TEXT,
      user_id INTEGER NOT NULL,
      total REAL NOT NULL,
      purchase_date TEXT NOT NULL,
      notes TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY(supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL,
      FOREIGN KEY(user_id) REFERENCES users(id)
    )''');
    await db.execute('''CREATE TABLE purchase_items(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      purchase_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      quantity INTEGER NOT NULL,
      purchase_price REAL NOT NULL,
      line_total REAL NOT NULL,
      FOREIGN KEY(purchase_id) REFERENCES purchases(id) ON DELETE CASCADE,
      FOREIGN KEY(product_id) REFERENCES products(id)
    )''');
    await db.execute('''CREATE TABLE stock_movements(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER,
      user_id INTEGER,
      type TEXT NOT NULL,
      quantity INTEGER NOT NULL,
      before_quantity INTEGER,
      after_quantity INTEGER,
      notes TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE SET NULL,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
    )''');
    await db.execute('''CREATE TABLE notifications(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER,
      type TEXT NOT NULL,
      title TEXT NOT NULL,
      body TEXT NOT NULL,
      scheduled_at TEXT,
      created_at TEXT NOT NULL,
      is_read INTEGER NOT NULL DEFAULT 0,
      system_notification_id INTEGER UNIQUE,
      FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
    )''');
    await db.execute('''CREATE TABLE settings(
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    )''');
    await db.execute('CREATE INDEX idx_products_name ON products(name)');
    await db.execute('CREATE INDEX idx_products_barcode ON products(barcode)');
    await db.execute('CREATE INDEX idx_products_category ON products(category_id)');
    await db.execute('CREATE INDEX idx_products_supplier ON products(supplier_id)');
    await db.execute('CREATE INDEX idx_products_expiry ON products(expiry_date)');
    await db.execute('CREATE INDEX idx_sales_date ON sales(created_at)');
    await db.execute('CREATE INDEX idx_purchases_date ON purchases(purchase_date)');
    await db.execute('CREATE INDEX idx_stock_date ON stock_movements(created_at)');
    await db.execute('CREATE INDEX idx_notifications_date ON notifications(created_at)');
  }

  Future<void> _seedDefaults() async {
    final userCount = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM users')) ?? 0;
    if (userCount == 0) {
      await db.insert('users', AppUser(username: 'admin', passwordHash: PasswordHasher.hash('Admin@123'), role: UserRole.admin, createdAt: DateTime.now()).toMap());
    }
    final categoryCount = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM categories')) ?? 0;
    if (categoryCount == 0) {
      for (final name in ['مواد غذائية','مستحضرات تجميل','أدوات مكتبية','إلكترونيات','ملابس','أدوية','أخرى']) {
        await db.insert('categories', {'name': name});
      }
    }
    final defaults = {
      'warehouse_name': 'مخزني', 'currency': 'ر.ع', 'notifications_enabled': '1',
      'notify_30': '1','notify_14':'1','notify_7':'1','notify_3':'1','notify_1':'1','notify_0':'1'
    };
    for (final e in defaults.entries) {
      await db.insert('settings', {'key': e.key, 'value': e.value}, conflictAlgorithm: ConflictAlgorithm.ignore);
    }
  }

  Future<String> databasePath() async => p.join(await getDatabasesPath(), AppConstants.databaseName);
  Future<void> close() async { await _db?.close(); _db = null; }
  Future<void> reopen() => init();

  Future<AppUser?> authenticate(String username, String password) async {
    final rows = await db.query('users', where: 'username = ? AND active = 1', whereArgs: [username.trim()], limit: 1);
    if (rows.isEmpty) return null;
    final user = AppUser.fromMap(rows.first);
    return PasswordHasher.verify(password, user.passwordHash) ? user : null;
  }

  Future<List<AppUser>> getUsers() async => (await db.query('users', orderBy: 'username')).map(AppUser.fromMap).toList();
  Future<int> addUser(String username, String password, UserRole role) => db.insert('users', AppUser(username: username.trim(), passwordHash: PasswordHasher.hash(password), role: role, createdAt: DateTime.now()).toMap());
  Future<int> updateUserPassword(int id, String password) => db.update('users', {'password_hash': PasswordHasher.hash(password)}, where: 'id=?', whereArgs: [id]);
  Future<int> deleteUser(int id) => db.delete('users', where: 'id=?', whereArgs: [id]);

  Future<List<Category>> getCategories() async => (await db.query('categories', orderBy: 'name')).map(Category.fromMap).toList();
  Future<int> saveCategory(Category c) => c.id == null ? db.insert('categories', c.toMap()) : db.update('categories', c.toMap()..remove('id'), where: 'id=?', whereArgs: [c.id]);
  Future<int> deleteCategory(int id) => db.delete('categories', where: 'id=?', whereArgs: [id]);

  Future<List<Supplier>> getSuppliers({String search=''}) async {
    final rows = await db.query('suppliers', where: search.isEmpty ? null : '(name LIKE ? OR phone LIKE ? OR email LIKE ?)', whereArgs: search.isEmpty ? null : ['%$search%','%$search%','%$search%'], orderBy: 'name');
    return rows.map(Supplier.fromMap).toList();
  }
  Future<int> saveSupplier(Supplier s) => s.id == null ? db.insert('suppliers', s.toMap()) : db.update('suppliers', s.toMap()..remove('id'), where: 'id=?', whereArgs: [s.id]);
  Future<int> deleteSupplier(int id) => db.delete('suppliers', where: 'id=?', whereArgs: [id]);

  Future<List<Product>> getProducts({String search='', int? categoryId, bool? lowStock}) async {
    final clauses = <String>[]; final args = <Object?>[];
    if (search.trim().isNotEmpty) { clauses.add('(p.name LIKE ? OR p.barcode LIKE ? OR CAST(p.id AS TEXT) LIKE ? OR c.name LIKE ? OR s.name LIKE ?)'); for(var i=0;i<5;i++) args.add('%${search.trim()}%'); }
    if (categoryId != null) { clauses.add('p.category_id=?'); args.add(categoryId); }
    if (lowStock == true) clauses.add('p.quantity <= p.minimum_stock');
    final rows = await db.rawQuery('''SELECT p.* FROM products p LEFT JOIN categories c ON c.id=p.category_id LEFT JOIN suppliers s ON s.id=p.supplier_id ${clauses.isEmpty ? '' : 'WHERE ${clauses.join(' AND ')}'} ORDER BY p.name''', args);
    return rows.map(Product.fromMap).toList();
  }
  Future<Product?> getProductByBarcode(String barcode) async { final r=await db.query('products',where:'barcode=?',whereArgs:[barcode],limit:1); return r.isEmpty?null:Product.fromMap(r.first); }
  Future<Product?> getProduct(int id) async { final r=await db.query('products',where:'id=?',whereArgs:[id],limit:1); return r.isEmpty?null:Product.fromMap(r.first); }

  Future<int> insertProduct(Product product, int userId) async => db.transaction((txn) async {
    final id = await txn.insert('products', product.toMap());
    await txn.insert('stock_movements', {'product_id':id,'user_id':userId,'type':'add','quantity':product.quantity,'before_quantity':0,'after_quantity':product.quantity,'notes':'إضافة منتج','created_at':DateTime.now().toIso8601String()});
    return id;
  });

  Future<void> updateProduct(Product product, int userId) async => db.transaction((txn) async {
    final old = await txn.query('products', where:'id=?', whereArgs:[product.id], limit:1);
    if(old.isEmpty) throw StateError('المنتج غير موجود');
    final before = old.first['quantity'] as int;
    await txn.update('products', product.toMap()..remove('id'), where:'id=?',whereArgs:[product.id]);
    if(before != product.quantity) await txn.insert('stock_movements', {'product_id':product.id,'user_id':userId,'type':'adjust','quantity':product.quantity-before,'before_quantity':before,'after_quantity':product.quantity,'notes':'تعديل كمية المنتج','created_at':DateTime.now().toIso8601String()});
  });

  Future<void> deleteProduct(int id, int userId) async => db.transaction((txn) async {
    final old=await txn.query('products',where:'id=?',whereArgs:[id],limit:1); if(old.isEmpty)return;
    final qty=old.first['quantity'] as int;
    await txn.insert('stock_movements', {'product_id':id,'user_id':userId,'type':'delete','quantity':-qty,'before_quantity':qty,'after_quantity':0,'notes':'حذف المنتج: ${old.first['name']}','created_at':DateTime.now().toIso8601String()});
    await txn.delete('products',where:'id=?',whereArgs:[id]);
  });

  Future<int> createSale(List<TransactionLine> lines, int userId, {String notes=''}) async => db.transaction((txn) async {
    if(lines.isEmpty) throw ArgumentError('لا توجد منتجات في الفاتورة');
    var total=0.0, profit=0.0;
    for(final line in lines) {
      final rows=await txn.query('products',where:'id=?',whereArgs:[line.product.id],limit:1);
      if(rows.isEmpty) throw StateError('منتج غير موجود');
      final q=rows.first['quantity'] as int;
      if(q < line.quantity) throw StateError('الكمية غير كافية للمنتج ${line.product.name}');
      total += line.quantity * line.unitPrice;
      profit += line.quantity * (line.unitPrice - (rows.first['purchase_price'] as num).toDouble());
    }
    final saleId=await txn.insert('sales', {'user_id':userId,'total':total,'profit':profit,'created_at':DateTime.now().toIso8601String(),'notes':notes});
    for(final line in lines) {
      final rows=await txn.query('products',where:'id=?',whereArgs:[line.product.id],limit:1);
      final before=rows.first['quantity'] as int; final purchase=(rows.first['purchase_price'] as num).toDouble(); final after=before-line.quantity;
      await txn.insert('sale_items', {'sale_id':saleId,'product_id':line.product.id,'quantity':line.quantity,'purchase_price':purchase,'selling_price':line.unitPrice,'line_total':line.quantity*line.unitPrice,'line_profit':line.quantity*(line.unitPrice-purchase)});
      await txn.update('products', {'quantity':after,'updated_at':DateTime.now().toIso8601String()},where:'id=?',whereArgs:[line.product.id]);
      await txn.insert('stock_movements', {'product_id':line.product.id,'user_id':userId,'type':'sale','quantity':-line.quantity,'before_quantity':before,'after_quantity':after,'notes':'بيع #$saleId','created_at':DateTime.now().toIso8601String()});
    }
    return saleId;
  });

  Future<int> createPurchase(List<TransactionLine> lines, int userId, {int? supplierId, String invoiceNumber='', DateTime? purchaseDate, String notes=''}) async => db.transaction((txn) async {
    if(lines.isEmpty) throw ArgumentError('لا توجد منتجات في الفاتورة');
    final total=lines.fold<double>(0,(a,b)=>a+b.quantity*b.unitPrice); final date=purchaseDate??DateTime.now();
    final purchaseId=await txn.insert('purchases', {'supplier_id':supplierId,'invoice_number':invoiceNumber,'user_id':userId,'total':total,'purchase_date':date.toIso8601String(),'notes':notes,'created_at':DateTime.now().toIso8601String()});
    for(final line in lines) {
      final rows=await txn.query('products',where:'id=?',whereArgs:[line.product.id],limit:1); if(rows.isEmpty) throw StateError('منتج غير موجود');
      final before=rows.first['quantity'] as int; final after=before+line.quantity;
      await txn.insert('purchase_items', {'purchase_id':purchaseId,'product_id':line.product.id,'quantity':line.quantity,'purchase_price':line.unitPrice,'line_total':line.quantity*line.unitPrice});
      await txn.update('products', {'quantity':after,'purchase_price':line.unitPrice,'updated_at':DateTime.now().toIso8601String()},where:'id=?',whereArgs:[line.product.id]);
      await txn.insert('stock_movements', {'product_id':line.product.id,'user_id':userId,'type':'purchase','quantity':line.quantity,'before_quantity':before,'after_quantity':after,'notes':'شراء #$purchaseId','created_at':DateTime.now().toIso8601String()});
    }
    return purchaseId;
  });

  Future<Map<String,num>> dashboard() async {
    final today=DateTime.now(); final start=DateTime(today.year,today.month,today.day).toIso8601String(); final end=DateTime(today.year,today.month,today.day+1).toIso8601String();
    final productCount=Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM products'))??0;
    final qty=(await db.rawQuery('SELECT COALESCE(SUM(quantity),0) v FROM products')).first['v'] as num;
    final low=Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM products WHERE quantity <= minimum_stock'))??0;
    final nowIso=DateTime.now().toIso8601String(); final soon=DateTime.now().add(const Duration(days:30)).toIso8601String();
    final expiring=Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM products WHERE expiry_date IS NOT NULL AND expiry_date >= ? AND expiry_date < ?',[nowIso,soon]))??0;
    final expired=Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM products WHERE expiry_date IS NOT NULL AND expiry_date < ?',[nowIso]))??0;
    final sale=(await db.rawQuery('SELECT COALESCE(SUM(total),0) v, COALESCE(SUM(profit),0) p FROM sales WHERE created_at >= ? AND created_at < ?',[start,end])).first;
    final purchase=(await db.rawQuery('SELECT COALESCE(SUM(total),0) v FROM purchases WHERE purchase_date >= ? AND purchase_date < ?',[start,end])).first['v'] as num;
    return {'products':productCount,'quantity':qty,'low':low,'expiring':expiring,'expired':expired,'salesToday':sale['v'] as num,'purchasesToday':purchase,'profitToday':sale['p'] as num};
  }

  Future<List<Map<String,Object?>>> salesTrend(int days) => db.rawQuery('''SELECT substr(created_at,1,10) day, SUM(total) total FROM sales WHERE created_at >= ? GROUP BY substr(created_at,1,10) ORDER BY day''',[DateTime.now().subtract(Duration(days:days)).toIso8601String()]);

  Future<List<Map<String,Object?>>> stockMovements({DateTime? start, DateTime? end}) => db.rawQuery('''SELECT m.*, p.name product_name, u.username FROM stock_movements m LEFT JOIN products p ON p.id=m.product_id LEFT JOIN users u ON u.id=m.user_id ${start==null?'':'WHERE m.created_at >= ? AND m.created_at < ?'} ORDER BY m.created_at DESC''', start==null?[]:[start.toIso8601String(),end!.toIso8601String()]);
  Future<List<Map<String,Object?>>> notificationRows() => db.rawQuery('SELECT n.*, p.name product_name FROM notifications n LEFT JOIN products p ON p.id=n.product_id ORDER BY n.created_at DESC');
  Future<int> markAllNotificationsRead() => db.update('notifications', {'is_read':1}, where:'is_read=0');
  Future<int> unreadCount() async => Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM notifications WHERE is_read=0'))??0;
  Future<int> addNotificationRecord(Map<String,Object?> data) => db.insert('notifications',data, conflictAlgorithm: ConflictAlgorithm.replace);
  Future<int> deleteProductNotificationRecords(int productId) => db.delete('notifications',where:'product_id=?',whereArgs:[productId]);

  Future<Map<String,Object?>> monthlySummary(int year,int month) async {
    final r=DateRangeHelper.monthRange(year,month); final s=r.start.toIso8601String(), e=r.end.toIso8601String();
    final exp=await db.query('products',where:'expiry_date >= ? AND expiry_date < ?',whereArgs:[s,e],orderBy:'expiry_date');
    final added=await db.query('products',where:'created_at >= ? AND created_at < ?',whereArgs:[s,e],orderBy:'created_at');
    final sales=await db.rawQuery('SELECT COALESCE(SUM(total),0) total, COALESCE(SUM(profit),0) profit, COUNT(*) count FROM sales WHERE created_at >= ? AND created_at < ?',[s,e]);
    final purchases=await db.rawQuery('SELECT COALESCE(SUM(total),0) total, COUNT(*) count FROM purchases WHERE purchase_date >= ? AND purchase_date < ?',[s,e]);
    final movements=await stockMovements(start:r.start,end:r.end);
    final alerts=await db.query('notifications',where:'created_at >= ? AND created_at < ?',whereArgs:[s,e],orderBy:'created_at DESC');
    return {'expiring':exp,'added':added,'sales':sales.first,'purchases':purchases.first,'movements':movements,'alerts':alerts};
  }

  Future<List<Map<String,Object?>>> reportRows(String type) async {
    switch(type) {
      case 'expired': return db.rawQuery('SELECT id,name,barcode,quantity,expiry_date FROM products WHERE expiry_date < ? ORDER BY expiry_date',[DateTime.now().toIso8601String()]);
      case 'expiring': return db.rawQuery('SELECT id,name,barcode,quantity,expiry_date FROM products WHERE expiry_date >= ? AND expiry_date < ? ORDER BY expiry_date',[DateTime.now().toIso8601String(),DateTime.now().add(const Duration(days:30)).toIso8601String()]);
      case 'low': return db.rawQuery('SELECT id,name,barcode,quantity,minimum_stock FROM products WHERE quantity <= minimum_stock ORDER BY quantity');
      case 'sales': return db.rawQuery('SELECT id,total,profit,created_at FROM sales ORDER BY created_at DESC');
      case 'purchases': return db.rawQuery('SELECT id,invoice_number,total,purchase_date FROM purchases ORDER BY purchase_date DESC');
      case 'profits': return db.rawQuery('SELECT id,total,profit,created_at FROM sales ORDER BY created_at DESC');
      case 'movements': return stockMovements();
      default: return db.rawQuery('SELECT id,name,barcode,quantity,minimum_stock,purchase_price,selling_price,expiry_date FROM products ORDER BY name');
    }
  }

  Future<String?> getSetting(String key) async { final r=await db.query('settings',where:'key=?',whereArgs:[key],limit:1); return r.isEmpty?null:r.first['value'] as String; }
  Future<void> setSetting(String key,String value) => db.insert('settings', {'key':key,'value':value},conflictAlgorithm:ConflictAlgorithm.replace);
  Future<Map<String,String>> allSettings() async => {for(final r in await db.query('settings')) r['key'] as String:r['value'] as String};

  Future<void> checkpoint() async { await db.rawQuery('PRAGMA wal_checkpoint(FULL)'); }
  Future<bool> databaseExists() async => File(await databasePath()).exists();
}

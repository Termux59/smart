import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final form = GlobalKey<FormState>();
  final u = TextEditingController();
  final p = TextEditingController();
  bool hide = true;
  bool remember = true;

  @override
  void dispose() {
    u.dispose();
    p.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final a = context.watch<AuthProvider>();
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 430),
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Form(
                    key: form,
                    child: Column(
                      children: [
                        const Icon(Icons.warehouse_rounded, size: 70),
                        const SizedBox(height: 16),
                        Text('تسجيل الدخول', style: Theme.of(context).textTheme.headlineSmall),
                        const SizedBox(height: 24),
                        TextFormField(
                          controller: u,
                          decoration: const InputDecoration(labelText: 'اسم المستخدم', prefixIcon: Icon(Icons.person_outline)),
                          validator: (v) => v == null || v.trim().isEmpty ? 'أدخل اسم المستخدم' : null,
                        ),
                        const SizedBox(height: 14),
                        TextFormField(
                          controller: p,
                          obscureText: hide,
                          decoration: InputDecoration(
                            labelText: 'كلمة المرور',
                            prefixIcon: const Icon(Icons.lock_outline),
                            suffixIcon: IconButton(onPressed: () => setState(() => hide = !hide), icon: Icon(hide ? Icons.visibility : Icons.visibility_off)),
                          ),
                          validator: (v) => v == null || v.isEmpty ? 'أدخل كلمة المرور' : null,
                        ),
                        CheckboxListTile(
                          value: remember,
                          onChanged: (v) => setState(() => remember = v ?? true),
                          title: const Text('تذكر تسجيل الدخول'),
                          contentPadding: EdgeInsets.zero,
                        ),
                        if (a.error != null)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: Text(a.error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
                          ),
                        SizedBox(
                          width: double.infinity,
                          child: FilledButton(
                            onPressed: a.loading
                                ? null
                                : () async {
                                    if (!(form.currentState?.validate() ?? false)) return;
                                    if (await a.login(u.text, p.text, remember) && mounted) {
                                      Navigator.pushNamedAndRemoveUntil(context, '/home', (r) => false);
                                    }
                                  },
                            child: a.loading
                                ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))
                                : const Text('دخول'),
                          ),
                        ),
                        const SizedBox(height: 10),
                        const Text('الحساب الأولي: admin / Admin@123', style: TextStyle(fontSize: 12)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

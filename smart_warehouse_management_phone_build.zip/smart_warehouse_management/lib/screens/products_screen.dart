import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/product.dart';
import '../providers/auth_provider.dart';
import '../providers/category_provider.dart';
import '../providers/product_provider.dart';
import 'product_form_screen.dart';
import 'barcode_scanner_screen.dart';

class ProductsScreen extends StatefulWidget {
  const ProductsScreen({super.key});
  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  final search = TextEditingController();
  @override
  void initState() {
    super.initState();
    Future.microtask(() async {
      await context.read<CategoryProvider>().load();
      await context.read<ProductProvider>().load();
    });
  }
  @override
  void dispose() { search.dispose(); super.dispose(); }

  Future<void> _scan() async {
    final code = await Navigator.push<String>(context, MaterialPageRoute(builder: (_) => const BarcodeScannerScreen()));
    if (code == null || !mounted) return;
    final provider = context.read<ProductProvider>();
    final found = provider.items.where((e) => e.barcode == code).firstOrNull;
    if (found != null && context.read<AuthProvider>().isAdmin) {
      await Navigator.push(context, MaterialPageRoute(builder: (_) => ProductFormScreen(product: found)));
    } else if (found == null) {
      await Navigator.push(context, MaterialPageRoute(builder: (_) => ProductFormScreen(initialBarcode: code)));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('المنتج موجود: ${found.name}')));
    }
    await provider.load();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.watch<ProductProvider>();
    final cats = context.watch<CategoryProvider>();
    return Scaffold(
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: search,
                        decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'بحث بالاسم، Barcode، التصنيف، المورد أو رقم المنتج'),
                        onChanged: (v) { p.search = v; p.load(); },
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton.filledTonal(onPressed: _scan, icon: const Icon(Icons.qr_code_scanner)),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: DropdownButtonFormField<int?>(
                        value: p.categoryId,
                        decoration: const InputDecoration(labelText: 'التصنيف'),
                        items: [const DropdownMenuItem(value: null, child: Text('الكل')), ...cats.items.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name)))],
                        onChanged: (v) { p.categoryId = v; p.load(); },
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: DropdownButtonFormField<bool?>(
                        value: p.lowStock,
                        decoration: const InputDecoration(labelText: 'حالة المخزون'),
                        items: const [DropdownMenuItem(value: null, child: Text('الكل')), DropdownMenuItem(value: true, child: Text('منخفض'))],
                        onChanged: (v) { p.lowStock = v; p.load(); },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            child: p.loading && p.items.isEmpty
                ? const Center(child: CircularProgressIndicator())
                : p.items.isEmpty
                    ? const Center(child: Text('لا توجد منتجات'))
                    : RefreshIndicator(
                        onRefresh: p.load,
                        child: ListView.separated(
                          padding: const EdgeInsets.fromLTRB(12, 4, 12, 90),
                          itemCount: p.items.length,
                          separatorBuilder: (_, __) => const SizedBox(height: 8),
                          itemBuilder: (c, i) => _ProductCard(product: p.items[i]),
                        ),
                      ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => const ProductFormScreen()));
          if (mounted) await context.read<ProductProvider>().load();
        },
        icon: const Icon(Icons.add),
        label: const Text('إضافة منتج'),
      ),
    );
  }
}

extension _FirstOrNull<T> on Iterable<T> { T? get firstOrNull => isEmpty ? null : first; }

class _ProductCard extends StatelessWidget {
  final Product product;
  const _ProductCard({required this.product});
  String status() {
    final d = product.daysRemaining;
    if (d == null) return 'بدون صلاحية';
    if (d < 0) return 'منتهي';
    if (d == 0) return 'ينتهي اليوم';
    return 'متبقي $d يوماً';
  }
  @override
  Widget build(BuildContext context) {
    final admin = context.read<AuthProvider>().isAdmin;
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: admin ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductFormScreen(product: product))) : null,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              CircleAvatar(
                radius: 30,
                backgroundImage: product.imagePath != null && File(product.imagePath!).existsSync() ? FileImage(File(product.imagePath!)) : null,
                child: product.imagePath == null ? const Icon(Icons.inventory_2) : null,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(product.name, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                    Text('Barcode: ${product.barcode.isEmpty ? '—' : product.barcode}'),
                    Text('الكمية: ${product.quantity} • الحد الأدنى: ${product.minimumStock}'),
                    Text('شراء: ${product.purchasePrice.toStringAsFixed(2)} • بيع: ${product.sellingPrice.toStringAsFixed(2)}'),
                    Text(status(), style: TextStyle(color: product.expiryState == ProductExpiryState.expired ? Theme.of(context).colorScheme.error : null)),
                  ],
                ),
              ),
              if (admin)
                PopupMenuButton<String>(
                  onSelected: (v) async {
                    if (v == 'edit') {
                      await Navigator.push(context, MaterialPageRoute(builder: (_) => ProductFormScreen(product: product)));
                      if (context.mounted) await context.read<ProductProvider>().load();
                    } else if (v == 'delete') {
                      final ok = await showDialog<bool>(
                        context: context,
                        builder: (c) => AlertDialog(
                          title: const Text('تأكيد الحذف'),
                          content: Text('هل أنت متأكد من حذف المنتج "${product.name}"؟'),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
                            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('حذف')),
                          ],
                        ),
                      );
                      if (ok == true && context.mounted) {
                        await context.read<ProductProvider>().remove(product, context.read<AuthProvider>().user!.id!);
                      }
                    }
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'edit', child: Text('تعديل')),
                    PopupMenuItem(value: 'delete', child: Text('حذف')),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }
}
